using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class _Enemy2 : MonoBehaviour
{   
    [Header("Set in Inspector: Enemy")]
    public float speed = 10f; // The speed in m/s
    public float fireRate = 0.3f; // Seconds/shot (Unused)
    public float health = 10;
    public int score = 100; // Points earned for destroying this
    private _BoundsCheck bndCheck;

    private int xDirection;

     private void Start()
    {
        if (Random.Range(0, 2) == 0)
        {
            xDirection = -1;
        }
        else
        {
            xDirection = 1;
        }
    }

    void Awake() { 
        bndCheck = GetComponent<_BoundsCheck>();
    }

    public Vector3 pos { 
        get {
            return(this.transform.position);
        }
        set {
            this.transform.position = value;
        }
}
    // Update is called once per frame
    void Update()
    {   
        MoveDown();
        MoveDiagonally();
        if (bndCheck != null && bndCheck.offDown){
         // Check to make sure it's gone off the bottom of the screen
            Destroy(gameObject);
        }
        if(bndCheck != null && bndCheck.offLeft){
            xDirection = 1;
        }
        if(bndCheck != null && bndCheck.offRight){
            xDirection = -1;
        }
    }

    public virtual void MoveDiagonally(){
        Vector3 tempPos = pos;
        tempPos.x +=  xDirection * speed * Time.deltaTime;
        pos = tempPos;
    }

    public virtual void MoveDown(){
        Vector3 tempPos = pos;
        tempPos.y -= speed * Time.deltaTime;
        pos = tempPos;
    }
}
